package com.example.eva2_7_activity_result;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    final int SECUNDARIA =1000;
    TextView txtVwDatos;
    Intent lanzar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVwDatos = findViewById(R.id.txtVwDatos);
        lanzar = new Intent(this, Secundaria.class);

    }


    public void clickLanzar(View view) {
        startActivityForResult(lanzar,SECUNDARIA);
    }

//                                  Que actividad -  Resultado a procesar - Se envian con intendos (bundles o extras)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case SECUNDARIA:
            //Algo con los datos
                if (resultCode == Activity.RESULT_OK){
                    //Aqui recibimos datos
                    txtVwDatos.setText(data.getStringExtra("MENSAJE"));
                } else {
                    Toast.makeText(this,"ACCION CANCELADA", Toast.LENGTH_SHORT).show();
                }
            break;
            default:
        }
    }
}
