package com.example.eva2_7_activity_result;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Secundaria extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secundaria);
    }

    public void clickEnviar(View v){
        Intent inDatos = new Intent();
        inDatos.putExtra("MENSAJE", "HOLA MUNDO");
        setResult(Activity.RESULT_OK, inDatos);
        finish();
    }
    public void clickCancelar(View v){

        setResult(Activity.RESULT_CANCELED);
        finish();
    }

}
