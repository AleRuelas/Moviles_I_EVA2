package com.example.eva2_6_bundles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {


    EditText edTxtNombre,edTxtEdad;
    RadioGroup generoG;
    Intent inDatos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edTxtNombre = findViewById(R.id.edTxtNombre);
        edTxtEdad = findViewById(R.id.edTxtEdad);
        generoG = findViewById(R.id.generoG);
        inDatos = new Intent(this, Secundaria.class);



    }
    public void click(View view){
        //INSETAR DATOD AL INTENTO
        Bundle bundle = new Bundle();
        bundle.putString("nombre",edTxtNombre.getText().toString());
        int iEdad= Integer.parseInt(edTxtEdad.getText().toString());
        bundle.putInt("edad",iEdad);
        int iGenero;
        if (generoG.getCheckedRadioButtonId() == R.id.btnF) {
            iGenero = 0;
        }else{
            iGenero = 1;
        }
        bundle.putInt("genero",iGenero);
        inDatos.putExtras(bundle);
        startActivity(inDatos);
    }
}
