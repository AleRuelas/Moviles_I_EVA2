package com.example.eva2_6_bundles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Secundaria extends AppCompatActivity {
    TextView txtVRecibir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secundaria);
        txtVRecibir = findViewById(R.id.txtVRecibir);
        Intent intent= getIntent();
        Bundle bundle = intent.getExtras();
        txtVRecibir.append(bundle.getString("nombre"+"")+"\n");
        txtVRecibir.append(bundle.getInt("edad") + "\n");
        switch (bundle.getInt("genero")){
            case 0:
                txtVRecibir.append("Femenino");
                break;
            case 1:
                txtVRecibir.append("Masculino");
                break;
        }



    }


}
