package com.example.eva2_4_activity_stack;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Actividad2 extends AppCompatActivity {

    //Intent inBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad2);
        //inBack = new Intent(this, MainActivity.class);
    }

    public void miClick (View view){
        finish();
        //startActivity(inBack);
    }

}
