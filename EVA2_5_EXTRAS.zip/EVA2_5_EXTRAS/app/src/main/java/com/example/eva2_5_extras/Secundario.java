package com.example.eva2_5_extras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Secundario extends AppCompatActivity {

    TextView txtVwMues;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secundario);
        txtVwMues = findViewById(R.id.txtVwMuest);
        Intent intent = getIntent();
        txtVwMues.setText(intent.getStringExtra("datos"));
    }


    public void cerrar(View view){
        finish();
    }
}
