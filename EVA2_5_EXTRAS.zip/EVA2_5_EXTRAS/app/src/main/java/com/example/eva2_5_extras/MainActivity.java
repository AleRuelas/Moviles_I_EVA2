package com.example.eva2_5_extras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edTxtDatos;
    Intent inLanzar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edTxtDatos = findViewById(R.id.edTxtDatos);
        inLanzar = new Intent(this,Secundario.class);
    }

    public void enviarInfo(View v){
        String sMensa = edTxtDatos.getText().toString();
        inLanzar.putExtra("datos",sMensa);
        //inLanzar.putExtra("num",100);
        startActivity(inLanzar);
    }

}
