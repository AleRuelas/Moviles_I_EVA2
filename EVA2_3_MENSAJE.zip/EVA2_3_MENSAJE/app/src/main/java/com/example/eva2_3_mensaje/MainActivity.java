package com.example.eva2_3_mensaje;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Intent inSMS;
    EditText edTxtTel, edTxtMen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edTxtTel=findViewById(R.id.edTxtTel);
        edTxtMen=findViewById(R.id.edTxtMen);


    }
    public void click(View view){
        String sTel = "smsto:"+edTxtTel.getText().toString();
        inSMS = new Intent(Intent.ACTION_SENDTO, Uri.parse(sTel));
        inSMS.putExtra("sms_body", edTxtMen.getText().toString());
        startActivity(inSMS);


    }

}
