package com.example.eva2_2_intentos_llamada;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Intent inMarcar;
    EditText edTxtTel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edTxtTel = findViewById(R.id.edTxtTel);


    }
    public void click(View view){
        View btnD = findViewById(R.id.btnD);
        View btnC = findViewById(R.id.btnC);
        String sTel = "tel:" + edTxtTel.getText().toString();
        if (view == btnD) {
            inMarcar = new Intent(Intent.ACTION_DIAL, Uri.parse(sTel));
        }else {
            inMarcar = new Intent(Intent.ACTION_CALL, Uri.parse(sTel));
        }

        startActivity(inMarcar);

    }
    //Action dial no pide permiso
    //Action call requiere permisos
}
